export class Rank {
	public roleId: string;
	public createdAt?: Date;
	public updatedAt?: Date;
	public guildId: string;
	public numInvites: number;
	public description: string;
}
