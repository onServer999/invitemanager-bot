export class PremiumSubscriptionGuild {
	public guildId: string;
	public memberId: string;
	public createdAt?: Date;
	public updatedAt?: Date;
}
