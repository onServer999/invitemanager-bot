export class Leave {
	public id: number;
	public guildId: string;
	public createdAt?: Date;
	public updatedAt?: Date;
	public memberId: string;
	public joinId: number;
}
