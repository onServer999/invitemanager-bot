export class Member {
	public id: string;
	public createdAt?: Date;
	public updatedAt?: Date;
	public name: string;
	public discriminator: string;
}
