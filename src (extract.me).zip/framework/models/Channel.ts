export class Channel {
	public id: string;
	public createdAt?: Date;
	public updatedAt?: Date;
	public guildId: string;
	public name: string;
}
